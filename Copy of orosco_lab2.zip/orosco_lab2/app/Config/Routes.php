<?php

use CodeIgniter\Router\RouteCollection;

/**
 */
$routes->get('/', 'MusicController::index');
$routes->post('/saveSong', 'MusicController::saveSong');
$routes->get('/searchSong', 'MusicController::searchSong');
$routes->post('/createPlaylist', 'MusicController::createPlaylist');
$routes->get('/playlists/(:any)', 'MusicController::playlists/$1');
$routes->post('/savePlaylist', 'MusicController::savePlaylist');